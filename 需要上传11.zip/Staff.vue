<template>
  <div style="width: 100%; height: 100vh; display: flex; flex-direction: column">
    <div style="display: flex">
      <span>
        <el-input v-model="inputName" placeholder="请输入姓名" style="width: 250px; margin-left: 10px"></el-input>
        <el-input v-model="inputUsername" placeholder="请输入账号" style="width: 250px; margin-left: 20px"></el-input>
        <el-select v-model="status" placeholder="选择状态" style="width: 100px; margin-left: 20px">
          <el-option
              v-for="item in statusOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value">
          </el-option>
        </el-select>
        <el-button type="primary" icon="el-icon-search" style="margin-left: 20px" @click="search">搜索</el-button>
        <el-button type="" icon="el-icon-refresh" style="margin-left: 20px" @click="reload">重置</el-button>
      </span>
      <span style="position: absolute;right: 0px">
        <el-button type="primary" style="margin-right: 20px" icon="el-icon-plus" @click="addStaff">添加员工</el-button>
      </span>

    </div>
    <div style="margin-top: 10px">
      <el-table :data="staffList" stripe="true" style="width: 100%; margin-top: 10px">
        <el-table-column prop="name" label="姓名" width="180"></el-table-column>
        <el-table-column prop="username" label="账号" width="180"></el-table-column>
        <el-table-column prop="phone" label="手机号"></el-table-column>
        <el-table-column prop="status" label="账号状态">
          <template slot-scope="scope"><span>{{ scope.row.status == 1 ? '正常':'禁用' }}</span></template>
        </el-table-column>
        <el-table-column prop="updateTime" label="最后修改时间"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button size="mini" type="warning"
                @click="handleDelete(scope.$index, scope.row)">{{ scope.row.status == '1' ? '禁用' : '启用' }}
            </el-button>
            <el-button size="mini" type="danger" @click="deleteStaff(scope.$index, scope.row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div style="align-items: flex-end">
      <el-pagination
          background
          layout="prev, pager, next"
          :total="1000">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import {API_URL} from '../../path/config'

export default {
  name: "Staff.vue",
  created() {
    axios.get(`${API_URL}/admin/staff/page?page=1&pageSize=10`, {
      headers: {
        'token': this.$store.state.token
      }
    })
        .then((res) => {
          // 检查响应数据是否存在
          if (res.data && res.data.data && Array.isArray(res.data.data.records)) {
            this.staffList = res.data.data.records;
          } else {
            console.error('Invalid response data:', res);
            // 添加更多的错误处理逻辑
          }
        })
        .catch((error) => {
          if (error.response && error.response.status === 404) {
            // 服务器返回 404，显示错误消息
            this.$message.error('Requested resource not found');
          } else {
            // 处理其他类型的错误
            console.error('Error fetching staff data:', error);
            // 也可以在这里显示一个更通用的错误消息
            this.$message.error('An error occurred while fetching staff data');
          }
        });
  },
  data() {
    return {
      inputName: null,
      inputUsername: null,
      status: 1,
      statusOptions: [
        { value: 1, label: '正常' },
        { value: 0, label: '禁用' }
      ],
      staffList: []
    }
  },
  methods: {
    //启用/禁用员工
    handleDelete(scope,row) {
      this.$confirm('确定修改该员工状态吗？', '警告', {
        type: 'warning'
      }).then(res => {
        // 用户点击了确认按钮
        axios.get(`${API_URL}/admin/staff/status?username=${row.username}&status=${row.status}`,{
          headers: {
            'token': this.$store.state.token
          }
        })
            .then((res) => {
              // 请求成功
              this.$message.success("修改成功！");
              // 刷新页面
              window.location.reload()
            })
            .catch(error => {
              // 请求失败
              console.error(error);
              this.$message.error("修改失败，请稍后重试！");
            });
      }).catch((err) => {
        // 用户点击了取消按钮
        this.$message.info("已取消操作")
        console.log('取消了操作');
      });
    },
    //点击编辑员工按钮
    handleEdit(scope,row){

    },
    //点击删除按钮
    deleteStaff(scope,row){
      this.$confirm('确定删除该员工状态吗？', '警告', {
        type: 'error'
      }).then(res => {
        axios.get(`${API_URL}/admin/staff/delete?username=${row.username}`,{
          headers: {
            'token': this.$store.state.token
          }
        })
          .then(response => {
            this.$message.success("删除成功！");
            window.location.reload()
          }).catch(error => {
          console.error(error);
          this.$message.error("系统出现错误！");
        })
      }).catch(error => {
        // 用户点击了取消按钮
        this.$message.info("已取消操作")
      })
    },
    //根据动态条件查询员工
    search() {
      let _this = this
      console.log(_this)
      axios.get(`${API_URL}/admin/staff/page?page=1&pageSize=10&name=${_this.inputName}&username=${_this.inputUsername}&status=${_this.status}`,{
        headers: {
          'token': this.$store.state.token
        }
      }).then((res) => {
        console.log("分页请求成功")
        _this.staffList = res.data.data.records;
      })
      .catch((error) => {
        // 这里处理请求失败的情况
        console.error('请求失败:', error);
      });
    },
    reload(){
      location.reload()
    },
    //添加员工
    addStaff(){
      this.$router.push('/addStaff');
    }
  }
}
</script>