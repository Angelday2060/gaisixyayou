# Cursor的基础使用
Ctrl + L 打开历史对话记录
## Tab智能助手

### 1.单行/多行补全

已有代码片段：

```java
//需求：写一个工具类计算数组平均值
public class ArrayUtils {
    //按tab会完成补全
}
```
按tab键- Cursor 自动生成代码:
```java
//需求：写一个工具类计算数组平均值
public class ArrayUtils {
    //按tab会完成补全
    public static double calculateAverage(int[] numbers) {
        if (numbers == null || numbers.length == 0) {
            throw new IllegalArgumentException("Array is empty");
        }
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        return (double) sum / numbers.length;
    }
}
```

### 2.智能代码重写
已有代码片段：
```java
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class Test {
    public static void arrayFor() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> evenNumbers = new ArrayList<>();
        for (int num : numbers) {
            if (num % 2 == 0) {
                evenNumbers.add(num);
            }
        }
    }
}
```
```java
//在循环上方添加注释://使用 stream 重构
//光标放在循环代码块的任意位置，按Tab键
public static void arrayStream() {
    List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
    List<Integer> evenNumbers = numbers.stream()
            .filter(num -> num % 2 == 0)
            .toList();
}
```

### 多行协同优化
Cursor 的 多行协同优化 核心能力:多行代码，一次性完成 语法升级、结构重组、安全修复.
* 多行数据联想
```java
int count;//普通变量
String name;//姓名
boolean isValid; //是否有效
double price;//价格
//按tab会继续联想变量类型
```
* 多行批量修改
```java
public static int add(int a,int b){
    //代码添加注释
    System.out.println("第一次输出!");
    System.out.println("第二次输出");
    System.out.println("第三次输出");
    System.out.println("第四次输出!");
    return o;
}
```
### 光标位置预测Tab to jump here

```java
//添加注释
public static int add(int a, int b) {
    return a + b;
}

public static int subtract(int a, int b) {
    return a - b;
}

public static int multiply(int a, int b) {
    return a * b;
}

public static int divide(int a, int b) {
    if (b != 0) {
        return a / b;
    } else {
        throw new IllegalArgumentException("Division by zero is not allowed.");
    }
}
```

```java
public class Test {
    //添加注释
    /**
     * Adds two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the sum of a and b
     */
    public static int add(int a, int b) {
        return a + b;
    }
    /**
     * Subtracts the second integer from the first.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the result of a minus b
     */
    public static int subtract(int a, int b) {
        return a - b;
    }
    /**
     * Multiplies two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the product of a and b
     */
    public static int multiply(int a, int b) {
        return a * b;
    }
    /**
     * Divides the first integer by the second.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the result of a divided by b
     * @throws IllegalArgumentException if b is zero
     */
    public static int divide(int a, int b) {
        if (b != 0) {
            return a / b;
        } else {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
    }
}
```

## 接收、部分接收和拒绝
```java
public class Student {
    //tab全部接收，esc拒绝接收，ctrl + 右箭头 部分接收
private String name;
private int age;
private String gender; 
}
```
默认不开启部分接收
需要在Cursor Settings -> Features -> Partial accepts


## Chat对话模式
1.Agent代理陵式(默认):允许Cursor学习和理解我们的项目代码，并且代表们可以直接进行项目代码更改!
[ 识别项目结构]
2.Ask对话模式:获取项目代码相关的解释和答案，但是不会直接修改项目代码![ 识别项目结构]
3.Manual手动模式:需要我们执行项目上下文(修改范围，后续会详细讲解)重点编辑![ 不识别项目结构]

## Ctrl + K 内联窗口

# 精准上下文指定
在curser工具，上下文（context） 可理解为让 AI 准确理解需求辅助编码的信息参考范围。
## Codebase Indexing 代码库检索
默认情况下，Cursor会自动检索项目文件。

查看codebase，点击右上角齿轮，Indexing

忽略文件设置
cursor读取项目的代码库并为其编制索引以支持其功能。可以通过将 .curserignore 文件添加到根目录来控制哪些文件被忽略和 curser 限制访问。
* **提升索引速度**:排除大型依赖、生成文件(如node_modules、dist)
* **避免干扰**:某些配置文件可能包含敏感信息或与当前任务无关

配置.cursorignore文件：
`cursor setting -> indexing -> Configure ignored files`


## Rules规则
rulers 规则可以为生成结果添加规则和限制，让AI生成的代码结合团队规范，减少人工二次修改成本。
* 可约束代码风格(如强制用驼峰命名、要求函数必须写注释)
* 能限定技术选型(如禁止使用某老旧库、优先用项目指定工具类)
* 提前指定核心参数(如提前设置连接数据库的地址和账号密码等)

### 配置方案
|维度|项目规则（Project Rules）| 用户规则（UserRules）|
| -- | --- | --- |
|作用范围|仅对当前项目生效，团队成员共享相同规则|对所有项目生效，个人专属配置|
|存储位置|项目根目录下的`.cursor/rules/`随意`.mdc`文件|用户配置目录（如`~/.cursor/rules`）|
|同步方式|随项目代码提交到版本库，团队共享|仅本地生效，不随项目同步|
|适用场景|统一团队编码规范（如函数注释格式、依赖版本）|个人习惯（如快捷键、AI 响应风格）|
> 如果项目规则和用户规则同时存在，并且规则冲突，项目规则优先级更高

### 项目配置规则

1. 项目规则配置
项目根目录下的`.cursor/rules/`随意`.mdc`文件
快捷键Ctrl + Shift + P > New Cursor Rule

2. 用户规则配置
进入Cusor Settings -> Rules -> User Rules
填写内容
> 用户规则不支持mdc语法 


## mdc语法
MDC（Markdown with Cursor）语法专门为编写项目规则设计的格式，结合 Markdown的可读性和元数据配置能力。

### 组成部分
1. 前置元数据（Frontmatter）
* 用`---`包裹的YAML格式配置
* 综艺规则的基本属性（如作用范围、优先级）
2. 规则内容（MD正文）
* 用Markdown语法写具体规则

### 前置元数据

| 字段| 作用 | 示例 |
|---|---|---|
|description|描述规则用途，指导 AI 如何应用规则|"前端组件编码规范"|
|globs|指定规则生效的文件范围（支持 glob 语法）|"src/**/*.{js,ts,jsx}"|
| priority 规则优先级（数值越大越优先），解决规则冲突 | 1000 |
| version| 规则版本号（可选）| "1.0.0"   |

示例：
```yml
---
# 官方约定字段(推荐用，AI更易理解)
description: "前端项目规则"
globs: "src/**/*.tsx"
priority: 1000
#自定义字段(白己或团队约定含义)
author: "技术团队"
review_date: "2025-06-04"
specia1_ru1e: "仅周一至周五生效"
---
```

### 规则内容
用Markdown的标题、列表、代码块等语法写具体规则。
代码风格规则（最常用）
```markdown
# 一、代码风格
1. 函数必须包含 `J`SDoc` 注释
    - 至少包含`@param`、`@return`描述
2. 变量名必须使用陀峰命名法。
3. 每行代码长度不超过120个字符。

# 二、技术选型
1. 禁止使用 eval() 函数
2. SQL 查询必须使用参数化查询，防止注入攻击
3. 敏感信息(如api密钥)，必须从环境变量读取
```
特殊语法：引用项目文件
用`@file`引用项目内的配置文件，让AI参考
```markdown
# 工具链配置
1. ESL int 规则必须符合 @file .eslintrc.js
2. 测试用例必须遵循Jest框架规范
```

完整示例
```markdown
---
description: "Java项目编码规范"
globs: "src/**/*.java"
priority: 1000
---

# 一、命名规范
1. 类名使用大驼峰命名法（如 `UserService`）
2. 方法名、变量使用小驼峰命名法（如 `getUserName`）
3. 常量使用全大写，单词间用下划线分隔（如 `MAX_COUNT`）

# 二、代码格式
1. 统一使用 4 空格缩进
2. 方法体左大括号不换行，右大括号单独一行
3. 运算符两侧、逗号后要加空格

# 三、注释规范
1. 类注释使用文档注释，说明类的功能
2. 方法注释说明功能、参数、返回值和异常
3. 关键业务逻辑处添加单行注释

# 四、代码规范
1. 方法不超过 80 行，避免过长方法
2. 避免深层嵌套，最多不超过 3 层
3. 优先使用 JDK 7+ 新特性
```

## @符号
使用@符号，在聊天中引用代码、文件、文档和其他上下文的指南

以下是所有可用 `@` 符号的列表：
- `@Files` - 引用项目中的特定文件
- `@Folders` - 引用整个文件夹以获得更广泛的上下文
- `@Code` - 引用代码库中的特定代码片段或符号
- `@Docs` - 访问文档和指南
- `@Git` - 访问 git 历史记录和更改
- `@Past Chats` - 使用汇总的 Composer 会话
- `@Cursor Rules` - 使用光标规则
- `@Web` - 参考外部 Web 资源和文档
- `@Lint Errors` - 引用 lint 错误（仅限 Chat）


使用@Docs来指定文档
Cursor Settings -> Indexing & Docs

@Web 参考外部资源（相当于联网搜索）

@Lint Errors 会自动捕获并提取当前活动文件中的任何linting错误和警告的上下文。（仅限Chat）
