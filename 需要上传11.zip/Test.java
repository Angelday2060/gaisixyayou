import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

public class Test {
    //使用Stream重构
    public static void arrayStream() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> evenNumbers = numbers.stream()
                .filter(num -> num % 2 == 0)
                .toList();
    }
    public static void arrayFor() {
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> evenNumbers = new ArrayList<>();
        for (int num : numbers) {
            if (num % 2 == 0) {
                evenNumbers.add(num);
            }
        }
    }
    //生成两个数字加减乘除的四个方法，并添加注释
    /**
     * Adds two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the sum of a and b
     */
    public static int add(int a, int b) {
        return a + b;
    }
    /**
     * Subtracts the second integer from the first.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the result of a minus b
     */
    public static int subtract(int a, int b) {
        return a - b;
    }
    /**
     * Multiplies two integers.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the product of a and b
     */
    public static int multiply(int a, int b) {
        return a * b;
    }
    /**
     * Divides the first integer by the second.
     *
     * @param a the first integer
     * @param b the second integer
     * @return the result of a divided by b
     * @throws IllegalArgumentException if b is zero
     */
    public static int divide(int a, int b) {
        if (b != 0) {
            return a / b;
        } else {
            throw new IllegalArgumentException("Division by zero is not allowed.");
        }
    }
}