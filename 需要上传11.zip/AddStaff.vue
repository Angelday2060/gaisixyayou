<template>
  <div style="width: 100%; width: 100vh; display: flex; align-items: center; justify-content: center">
    <div style="background-color: #eaeaee; margin: 20px; padding: 50px; box-shadow: #cccccc 10px 10px 5px">
      <div class="form-staff">
        <el-form ref="form" :rules="rules" :model="form" label-width="80px">
          <el-form-item label="账号" prop="username">
            <el-input v-model="form.username" placeholder="请输入账号"></el-input>
          </el-form-item>
          <el-form-item label="姓名" prop="name">
            <el-input v-model="form.name" placeholder="请输入员工姓名"></el-input>
          </el-form-item>

          <el-form-item label="密码" prop="password">
            <el-input v-model="form.password" placeholder="密码"></el-input>
          </el-form-item>

          <el-form-item label="手机号" prop="phone">
            <el-input v-model="form.phone" placeholder="手机号"></el-input>
          </el-form-item>

        </el-form>
      </div>
      <div class="button-staff" style="display: flex; justify-content: space-around">
        <el-button type="info" style="width: 100px" @click="cancel()">取消</el-button>
        <el-button type="primary" style="width: 100px" @click="submit()">提交</el-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AddStaff.vue",
  data(){
    return {
      form: {
        username: '',
        name: '',
        password: '',
        phone: '',
        idNumber: ''
      },
      rules: {
        username: [
          {required: true, message: '请输入账号', trigger: 'blur'},
          {min: 5, max: 10, message: '长度在 5 到 10 个字符', trigger: 'blur'}
        ],
        name: [
          {required: true, message: '请输入员工姓名', trigger: 'blur'},
          {min: 2, max: 5, message: '长度在 2 到 5 个字符', trigger: 'blur'}
        ],
        password: [
          {required: true, message: '请输入密码', trigger: 'blur'},
          {min: 5, max: 64, message: '您输入的密码格式不正确', trigger: 'blur'}
        ],
        phone: [
          {required: true, message: '请输入手机号', trigger: 'blur'},
          {min: 11, max: 11, message: '您输入的手机号格式不正确', trigger: 'blur'}
        ]
      }
    }
  },
  methods:{
    //提交按钮
    submit(){
      let _this = this
      axios.post("http://192.168.127.8:8080/admin/staff/add",_this.form).then(resp => {
        this.$message.success("添加成功");
        this.$router.push({name : 'Staff'})
      })
    },
    //取消按钮
    cancel(){
      this.$message.info("已取消操作");
      this.$router.push({name:'Staff'})
    }
  }
}
</script>
